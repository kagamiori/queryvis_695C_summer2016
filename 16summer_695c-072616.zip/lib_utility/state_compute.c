#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include </home/kagamiori/Courses/16spring 695C/lib_utility/sqlite3.h>
//---------------------------------------
typedef enum ErrorCode {EC_OK, EC_FAIL} ErrorCode;
//typedef enum TableName {part, supplier, partsupp, customer, nation, region, lineitem, orders, n_a} TableName; //12345678
//typedef enum TableName {nation, region, supplier, customer, partsupp, orders, lineitem, part, n_a} TableName; //56243871
typedef enum TableName {supplier, nation, region, partsupp, customer, orders, part, lineitem, n_a} TableName;
const int TABLE_NUM = 8;
int res_i = 0; //number of result returned by the last executed query
//---------------------------------------
static int callback_cleanindex(void *result_ls, int argc, char **argv, char **azColName)
{
	//int i;
	//char **result_ls = (char **)malloc(sizeof(char *), 200);
	char **res_arr = (char **)result_ls;
	res_arr[res_i] = (char *)malloc(sizeof(char) * 20);
	strcpy(res_arr[res_i], argv[0]);
	++res_i;
	
	//printf("\n");
	return 0;
	/*char *ErrMsg = 0;
	sqlite3 *db = (sqlite3 *)void_db;
	char drop_query[50];
	int rc;
	strcpy(drop_query, "drop index ");
	strcat(drop_query, argv[0]);
	strcat(drop_query, ";\0");*/
	
	/*rc = sqlite3_exec(db, drop_query, NULL, 0, &ErrMsg);
	
	if (rc != SQLITE_OK)
	{
		printf("Error in callback_dropindex()\n");
	}*/
	//system("./sqlite3 ./tpch.db 'drop index idx8'");
	
	//return SQLITE_OK;
}
//----------------------------------------
static int callback_empty(void *NotUsed, int argc, char **argv, char **azColName)
{
	int i;
	for(i=0; i<argc; i++)
	{
		printf("%s = %s\n", azColName[i], argv[i] ? argv[i] : "NULL");
	}
	printf("\n");
	return 0;
}
//---------------------------------------
ErrorCode clean_index(sqlite3 *db)
{
	//sqlite3 *db;
	char *ErrMsg = 0;
	int rc;
	sqlite3_stmt *ppStmt;
	const char **tmp;
	//sqlite3_int64 out_status;
	//const char *out_status2;
	//FILE *fp;
	char *query = "SELECT name FROM sqlite_master WHERE type == 'index'";
	int len = 0;
	//int query_no;
	
	/*rc = sqlite3_open(argv[1], &db);
	if (rc != SQLITE_OK)
	{
		printf("SQL error open db: %s\n", ErrMsg);
		sqlite3_free(ErrMsg);
		return EC_FAIL;
	}*/
	
	char **result_ls = (char **)malloc(sizeof(char *) * 200);
	
	res_i = 0;
	rc = sqlite3_exec(db, query, callback_cleanindex, result_ls, &ErrMsg);
	if (rc != SQLITE_OK)
	{
		printf("Error in clean_index()\n");
		return EC_FAIL;
	}
	
	int i, res_num;
	char drop_query[50];
	res_num = res_i;
	for (i = 0; i != res_num; ++i)
	{
		strcpy(drop_query, "drop index ");
		strcat(drop_query, result_ls[i]);
		res_i = 0;
		rc = sqlite3_exec(db, drop_query, callback_empty, NULL, &ErrMsg);
		if (rc != SQLITE_OK)
		{
			printf("error in iter: %d\n", i);
			return EC_FAIL;
		}
	}
	
	return EC_OK;
}
//--------------------------------------
ErrorCode generate_scanstatus(sqlite3 *db, const char *query_file, const char *output_file, /*out*/int *max_loop_no, /*out*/int *query_no)
{
	char *ErrMsg = 0;
	int rc;
	sqlite3_stmt *ppStmt;
	const char **tmp = NULL;
	sqlite3_int64 out_status;
	const char *out_status2;
	FILE *fp, *fp_out;
	//int query_no;
	
	fp = fopen(query_file, "r");
	fp_out = fopen(output_file, "w+");
	if (fp == NULL || fp_out == NULL)
	{
		printf("open file error\n");
		return EC_FAIL;
	}
	
	*query_no = 0;
	int len;
	char *query = NULL;
	int loop_no;
	bool more_loop;
	int scan_no;
	int i;
	while (getline(&query, &len, fp) != -1)
	{
		(*query_no)++;
		rc = sqlite3_prepare(db, query, 50000, &ppStmt, tmp);
		if (rc != SQLITE_OK || query[0] == '\n')
		{
			if (query[0] == '\n')
			{
				(*query_no)--;
			}
			else
			{
				printf("SQL error scanstatus: %s\n", ErrMsg);
				sqlite3_free(ErrMsg);
			}
			//getline(&query, &len, fp);
			//getline(&query, &len, fp);	
			continue;
		}
		
		
		fprintf(fp_out, "query: %d\n", *query_no);
		loop_no = 0;
		more_loop = true;
		while (more_loop)
		{
			more_loop = false;
			rc = sqlite3_stmt_scanstatus(ppStmt, loop_no, SQLITE_SCANSTAT_NAME, &out_status2);
			rc = sqlite3_stmt_scanstatus(ppStmt, loop_no, SQLITE_SCANSTAT_NVISIT, &out_status);
			if (rc == 0)
			{
				i = 0;
				more_loop = true;
				scan_no = out_status;
				//fprintf(fp_out, "loop %d: rc = %d table = %s scanstatus = %d\n", loop_no, rc, out_status2, out_status);
				
				rc = sqlite3_step(ppStmt);
				//fprintf(fp_out, "step %d: rc = %d\n", i, rc);
				while (rc != 101)
				{
					rc = sqlite3_stmt_scanstatus(ppStmt, loop_no, SQLITE_SCANSTAT_NVISIT, &out_status);
					rc = sqlite3_stmt_scanstatus(ppStmt, loop_no, SQLITE_SCANSTAT_NAME, &out_status2);
					if (scan_no < out_status)
						scan_no = out_status;
					//fprintf(fp_out, "loop %d: rc = %d table = %s scanstatus = %d\n", loop_no, rc, out_status2, out_status);
					rc = sqlite3_step(ppStmt);
			
					i++;
					//fprintf(fp_out, "step %d: rc = %d\n", i, rc);
				}
				
				fprintf(fp_out, "summary: loop %d table = %s max_scanstatus = %d\n", loop_no, out_status2, scan_no);
			}
			++loop_no;
		}
		fprintf(fp_out, "#\n");
		if (*max_loop_no < loop_no)
			*max_loop_no = loop_no;
	}
	
	fclose(fp);
	fclose(fp_out);
	return EC_OK;
}
//--------------------------------------
ErrorCode process_scanstatus_output(const char *data_file, const char *output_file, int max_loop_no, int query_no)  //debug to here 02092016
{
	FILE *fp, *fp_out;
	fp = fopen(data_file, "r");
	fp_out = fopen(output_file, "w+");
	if (fp == NULL || fp_out == NULL)
	{
		printf("open file error\n");
		return EC_FAIL;
	}
	
	int i;
	int q_n, loop_n, rc1, rc2, scanstatus, step;
	int match;
	int scan_no = -1;
	int last_loop = 0;
	int last_scanstatus = 0;
	char table_name[50];
	char last_table[50];
	char *tmp = NULL;
	int len;
	//loop_n = 0;
	for (i = 0; i != query_no; ++i)
	{
		scanstatus = -1;
		scan_no = -1;
		fscanf(fp, "query: %d\n", &q_n);
		fprintf(fp_out, "query: %d\n", q_n);
		
		/*fscanf(fp, "loop %d: rc = %d, scanstatus = %d\n", &loop_n, &rc1, &scanstatus);
		match = fscanf(fp, "step %d: rc = %d\n", &step, &rc2);
		if (rc1 != 0)
			continue;*/
		/*match = 2;
		while (match  == 2)
		{
			fscanf(fp, "loop %d: rc = %d table = %s scanstatus = %d\n", &loop_n, &rc1, &table_name, &scanstatus);
			match = fscanf(fp, "step %d: rc = %d\n", &step, &rc2);
			/*if (rc1 != 0)
				continue;*/
			
		/*	if (loop_n != last_loop)
			{
				if (rc1 != 0)
				{
					fprintf(fp_out, "loop %d: table = N/A scanstatus = -1\n", last_loop);
				}
				else
				{
					fprintf(fp_out, "loop %d: table = %s scanstatus = %d\n", last_loop, last_table, last_scanstatus);
				}
			}
			strcpy(last_table, table_name);
			last_scanstatus = scanstatus;
			last_loop = loop_n;
		}*/
		while (fscanf(fp, "summary: loop %d table = %s max_scanstatus = %d\n", &loop_n, &table_name, &scanstatus) == 3)
		{
			fprintf(fp_out, "loop %d: table = %s scanstatus = %d\n", loop_n, table_name, scanstatus);
		}
		fprintf(fp_out, "\n");
		getline(&tmp, &len, fp);
	}
	
	fclose(fp);
	fclose(fp_out);
	return EC_OK;
}
//--------------------------------------
ErrorCode generate_tsv(const char *input_file, const char *output_file, int max_loop_no, int query_no)
{
	int record[500][20];
	FILE *fp, *fp_out;
	fp = fopen(input_file, "r");
	fp_out = fopen(output_file, "w+");
	if (fp == NULL || fp_out == NULL)
	{
		printf("open file error\n");
		return EC_FAIL;
	}
	
	int i, j;
	int q_i, step_i, loop_i;
	char table_s[50];
	int match;
	TableName tbn;
	char *tmp = NULL;
	int len;
	for (i = 0; i != query_no; ++i)
	{
		fscanf(fp, "query: %d\n", &q_i);
		match = 3;
		while (fscanf(fp, "loop %d: table = %s scanstatus = %d\n", &loop_i, &table_s, &step_i) == 3)
		{
			//match = fscanf(fp, "loop %d: table = %s scanstatus = %d\n", &loop_i, &table_s, &step_i);
			if (step_i == -1)
				continue;
			
			if (strcmp(table_s, "part") == 0)
				tbn = part;
			else if (strcmp(table_s, "supplier") == 0)
				tbn = supplier;
			else if (strcmp(table_s, "partsupp") == 0)
				tbn = partsupp;
			else if (strcmp(table_s, "customer") == 0)
				tbn = customer;
			else if (strcmp(table_s, "nation") == 0)
				tbn = nation;
			else if (strcmp(table_s, "region") == 0)
				tbn = region;
			else if (strcmp(table_s, "lineitem") == 0)
				tbn = lineitem;
			else if (strcmp(table_s, "orders") == 0)
				tbn = orders;
			else
				tbn = n_a;
				
			record[q_i][tbn] += step_i;
		}
		//getline(&tmp, &len, fp);
	}
	
	fprintf(fp_out, "table	query	scanstep\n");
	for (i = 0; i != TABLE_NUM; ++i)
	{
		for (j = 0; j != query_no; ++j)
		{
			fprintf(fp_out, "%d	%d	%d\n", i+1, j, record[j][i]);
		}
	}
	
	return EC_OK;
}
//--------------------------------------
ErrorCode generate_tsv_with_summary_cells(const char *input_file, const char *output_file, int max_loop_no, int query_no)
{
	int record[500][20];
	FILE *fp, *fp_out;
	fp = fopen(input_file, "r");
	fp_out = fopen(output_file, "w+");
	if (fp == NULL || fp_out == NULL)
	{
		printf("open file error\n");
		return EC_FAIL;
	}
	
	int i, j;
	int q_i, step_i, loop_i;
	char table_s[50];
	int match;
	TableName tbn;
	char *tmp = NULL;
	int len;
	for (i = 0; i != query_no; ++i)
	{
		fscanf(fp, "query: %d\n", &q_i);
		match = 3;
		while (fscanf(fp, "loop %d: table = %s scanstatus = %d\n", &loop_i, &table_s, &step_i) == 3)
		{
			//match = fscanf(fp, "loop %d: table = %s scanstatus = %d\n", &loop_i, &table_s, &step_i);
			if (step_i == -1)
				continue;
			
			if (strcmp(table_s, "part") == 0)
				tbn = part;
			else if (strcmp(table_s, "supplier") == 0)
				tbn = supplier;
			else if (strcmp(table_s, "partsupp") == 0)
				tbn = partsupp;
			else if (strcmp(table_s, "customer") == 0)
				tbn = customer;
			else if (strcmp(table_s, "nation") == 0)
				tbn = nation;
			else if (strcmp(table_s, "region") == 0)
				tbn = region;
			else if (strcmp(table_s, "lineitem") == 0)
				tbn = lineitem;
			else if (strcmp(table_s, "orders") == 0)
				tbn = orders;
			else
				tbn = n_a;
				
			record[q_i][tbn] += step_i;
		}
		//getline(&tmp, &len, fp);
	}
	
	fprintf(fp_out, "table	query	scanstep\n");
	int row_sum;
	int column_sum[query_no+1];
	for (j = 0; j != query_no; ++j)
		column_sum[j] = 0;
		
	for (i = 0; i != TABLE_NUM; ++i)
	{
		row_sum = 0;
		for (j = 0; j != query_no; ++j)
		{
			fprintf(fp_out, "%d	%d	%d\n", i+1, j, record[j][i]);
			row_sum += record[j][i];
			column_sum[j] += record[j][i];
		}
		
		fprintf(fp_out, "%d	%d	%d\n", i+1, query_no, row_sum);
	}
	
	row_sum = 0;
	for (j = 0; j != query_no; ++j)
	{
		fprintf(fp_out, "%d	%d	%d\n", TABLE_NUM+1, j, column_sum[j]);
		row_sum += column_sum[j];
	}
	fprintf(fp_out, "%d	%d	%d\n", TABLE_NUM+1, query_no, row_sum);
	
	return EC_OK;
}
//--------------------------------------
ErrorCode compute_new_state(sqlite3 *db, const char *query_file, const char *output_file, const char **idx_list, int idx_list_len)	//entries in idx_list are the exact the last part of create index statement
{
	ErrorCode ec;
	ec = clean_index(db);
	if (ec != EC_OK)
	{
		printf("Error in compute_new_state()\n");
		return EC_FAIL;
	}
	
	char createidx_query[50];
	int i;
	char *ErrMsg = 0;
	int rc;

	for (i = 0; i != idx_list_len; ++i)
	{
		strcpy(createidx_query, "create index ");
		strcat(createidx_query, idx_list[i]);
		
		rc = sqlite3_exec(db, createidx_query, callback_empty, 0, &ErrMsg);
		if (rc != SQLITE_OK)
		{
			printf("create index fail\n");
			return EC_FAIL;
		}
	}
	
	int max_loop_no = -1;
	int query_no = -1;
	ec = generate_scanstatus(db, query_file, "scanstatus.txt", &max_loop_no, &query_no); 
	if (ec != EC_OK)
	{
		printf("Error in compute_new_state()\n");
		return EC_FAIL;
	}
	
	ec = process_scanstatus_output("scanstatus.txt", "statistics.txt", max_loop_no, query_no);
	ec = generate_tsv_with_summary_cells("statistics.txt", output_file, max_loop_no, query_no);
	
	return EC_OK;
}
//==============================================
int main(int argc, const char **argv)  //argv[0] = exe name, argv[1] = db, argv[2] = query_file, argv[3..] = idx_list ("tab1(col1) tab2(col2) ...")
{
	sqlite3 *db;
	char *ErrMsg = 0;
	
	if (argc < 4)
	{
		printf("Usage: %s Database QueryFile IndexList OutputFile\n", argv[0]);
		return 0;
	}
	
	int rc = sqlite3_open(argv[1], &db);
	if (rc != SQLITE_OK)
	{
		printf("SQL error open db: %s\n", ErrMsg);
		sqlite3_free(ErrMsg);
	}
	
	//char idx_list[50][50];	//idx_list[i] = ith create index postfix
	char **idx_list = (char **)malloc(sizeof(char *) * 50);
	int i;
	int idx_list_len = 0;
	char buff[10];
	for (i = 4; i != argc; ++i)
	{
		idx_list[idx_list_len] = (char *)malloc(sizeof(char) * 50);
		strcpy(idx_list[idx_list_len], "idx");
		snprintf(buff, 10, "%d", idx_list_len);
		strcat(idx_list[idx_list_len], buff);
		strcat(idx_list[idx_list_len], " on ");
		strcat(idx_list[idx_list_len], argv[i]);
		
		++idx_list_len;
	}
	
	compute_new_state(db, argv[2], argv[3], idx_list, idx_list_len);
	
	return 0;
}





















