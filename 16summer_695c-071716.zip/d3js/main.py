#run this script from /home/kagamiori/Courses/16summer_695c/

from flask import Flask
import subprocess

app = Flask(__name__,
            static_folder="../d3js/",
            static_url_path="/d3js")

@app.route("/")
def index():
    return open('redirect.html').read()

@app.route("/comp_avg/<parameter>")
def cluster(parameter):
    try:
    	args = ["./d3js/comp_avg"] + ['./d3js/' + x for x in parameter.split()]
    	print args
        print subprocess.check_output(args)
        out = open('avg.tsv').read()
        return out
    except:
        return "<html><body>No such file</body></html>"

#@app.route("/test_json/<parameter>")
#def test_json(parameter):
#    result = subprocess.check_output("call some fancy clustering", parameter)
#    return ' { "result": "%s" } ' % result

if __name__ == "__main__":
    app.run()
