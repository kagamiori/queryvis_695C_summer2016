//http://linux.die.net/man/3/readdir

#include <stdio.h>
#include <sys/types.h>
#include <dirent.h>
#include <stdlib.h>
#include <string.h>
//#include <string>
#include <math.h>
#include "cluster.h"
//-----------------------------------
//using namespace std;
//-----------------------------------
char **fn_list = (char **)malloc(sizeof(char *) * 100);
int fn_cnt = 0;
const int TABLE_NUM = 8;//8
const int QUERY_NUM = 14;//14
const int STATE_NUM = 53;//41
double record[STATE_NUM][TABLE_NUM * QUERY_NUM];		//[query][table][state], query from 0, state from 0, table from 1
int mask[STATE_NUM][TABLE_NUM * QUERY_NUM];
double weight[TABLE_NUM * QUERY_NUM];
//-----------------------------------
void list_filename()
{
	DIR *dp;
	struct dirent *ep;

	dp = opendir ("./");
	if (dp != NULL)
	{
		while (ep = readdir (dp))
		{
			//puts (ep->d_name);
			if (strstr(ep->d_name, ".tsv") != NULL)
			{
				fn_list[fn_cnt] = (char *)malloc(sizeof(char) * 256);
				strcpy(fn_list[fn_cnt], ep->d_name);
				++fn_cnt;
			}
		}
		(void) closedir (dp);
	}
	else
		perror ("Couldn't open the directory");

	return;
}
//-----------------------------------
int main()
{
	FILE *fp;
	int tmpi, tmpj, tmp_step;
	char *tmps = (char *)malloc(sizeof(char) * 20);
	
	
	list_filename();
	
	int i, j, k, l;
	
	for (i = 1; i <= STATE_NUM; ++i)
	{
		for (j = 0; j < QUERY_NUM * TABLE_NUM; ++j)
		{
			record[i][j] = 0;
			mask[i][j] = 1;
			weight[j] = 1;
		}
	}
	
	
	//---------for-debug-begin----------
	//strcpy(fn_list[0], "idx_none.tsv");
	//fn_cnt = 1;
	//---------for-debug-end------------
	
	for (i = 0; i < fn_cnt; ++i)
	{
		fp = fopen(fn_list[i], "r");
		if (fp == NULL)
		{
			printf("open file error: %s\n", fn_list[i]);
			return 0;
		}
		
		fscanf(fp, "%s	%s	%s\n", tmps, tmps, tmps);
		for (j = 1; j <= TABLE_NUM * QUERY_NUN; ++j)
		{
			fscanf(fp, "%d	%d	%d\n", &tmpi, &tmpj, &tmp_step);
			record[i][j] = tmp_step;
		}
		fclose(fp);
	}
	
	
	Node *res_tree = treecluster(STATE_NUM, TABLE_NUM * QUERY_NUM, record, mask, weight, 0, 'e', 'a', NULL);
	
	
	
	
	
	
	
	
	
