from flask import Flask
import subprocess

app = Flask(__name__,
            static_folder="files",
            static_url_path="/static")

@app.route("/")
def hello():
    return open('index.html').read()

@app.route("/get_cluster_average/<parameter>")
def cluster(parameter):
    try:
        result = subprocess.check_output(["ls", "/tmp/" + parameter])
        return "<html><body><pre>" + result + "</pre></body></html>"
    except:
        return "<html><body>No such file</body></html>"

@app.route("/test_json/<parameter>")
def test_json(parameter):
    result = subprocess.check_output("call some fancy clustering", parameter)
    return ' { "result": "%s" } ' % result

if __name__ == "__main__":
    app.run()
