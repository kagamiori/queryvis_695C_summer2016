#!/bin/bash

cd d3js
ls *.tsv > data/datasets.txt
