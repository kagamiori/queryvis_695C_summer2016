//#include <iostream>
//#include <fstream>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
//-------------------------
//using namespace std;
//-------------------------
const int TABLE_NUM = 9;
const int QUERY_NUM = 15;
//-------------------------
int main(int argc, const char **argv)	//argv[] contains .tsv filenames
{
	printf("RUNNING\n");
	int i, j, k, l;
	int rec_sum[TABLE_NUM][QUERY_NUM];
	for (i = 0; i < TABLE_NUM; ++i)
		for (j = 0; j < QUERY_NUM; ++j)
			rec_sum[i][j] = 0;
			
	int tab, que, step;
	char *tmps = (char *)malloc(sizeof(char) * 50);
	FILE *in;
	
	for (k = 1; k < argc; ++k)
	{
		in = fopen(argv[k], "r");
		if (in == NULL)
		{
			printf("open file error\n");
			return 0;
		}
		
		fscanf(in, "%s	%s	%s\n", tmps, tmps, tmps);
		for (i = 0; i < TABLE_NUM; ++i)
		{
			for (j = 0; j < QUERY_NUM; ++j)
			{
				l = fscanf(in, "%d	%d	%d\n", &tab, &que, &step);
				rec_sum[tab-1][que] += step;
				printf("%d %d\n", i, j);
			}
		}
		fclose(in);
	}
	
	FILE *out = fopen("avg.tsv", "w+");
	if (!out)
	{
		printf("open file error\n");
		return 0;
	}
	
	fprintf(out, "table\tquery\tscanstep\n");
	for (i = 0; i < TABLE_NUM; ++i)
	{
		for (j = 0; j < QUERY_NUM; ++j)
		{
			fprintf(out, "%d\t%d\t%d\n", i+1, j, (rec_sum[i][j] / (argc - 1)));
		}
	}
	
	fclose(out);
	return 0;
	
}
