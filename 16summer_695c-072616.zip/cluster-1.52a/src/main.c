/* The C clustering library.
 * Copyright (C) 2002 Michiel Jan Laurens de Hoon.
 *
 * This library was written at the Laboratory of DNA Information Analysis,
 * Human Genome Center, Institute of Medical Science, University of Tokyo,
 * 4-6-1 Shirokanedai, Minato-ku, Tokyo 108-8639, Japan.
 * Contact: mdehoon 'AT' gsc.riken.jp
 * 
 * Permission to use, copy, modify, and distribute this software and its
 * documentation with or without modifications and for any purpose and
 * without fee is hereby granted, provided that any copyright notices
 * appear in all copies and that both those copyright notices and this
 * permission notice appear in supporting documentation, and that the
 * names of the contributors or copyright holders not be used in
 * advertising or publicity pertaining to distribution of the software
 * without specific prior permission.
 * 
 * THE CONTRIBUTORS AND COPYRIGHT HOLDERS OF THIS SOFTWARE DISCLAIM ALL
 * WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL THE
 * CONTRIBUTORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY SPECIAL, INDIRECT
 * OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOFTWARE.
 * 
 */

/* If the user specified any command-line parameters, we run the command-line
 * version of Cluster 3.0. If not, we run the GUI version of Cluster 3.0, if
 * available.
 */

/*#include "gui.h"
#include "command.h"

int main(int argc, char *argv[])
{
#ifdef HAVE_GUI
    if (argc <= 1)
        return guimain(argc, argv);
    else
#endif
        return commandmain(argc, argv);
}*/


//http://linux.die.net/man/3/readdir

#include <stdio.h>
#include <sys/types.h>
#include <dirent.h>
#include <stdlib.h>
#include <string.h>
//#include <string>
#include <math.h>
#include "cluster.h"
//-----------------------------------
//using namespace std;
//-----------------------------------
/*char **fn_list = (char **)malloc(sizeof(char *) * 100);
int fn_cnt = 0;
const int TABLE_NUM = 8;//8
const int QUERY_NUM = 14;//14
const int STATE_NUM = 53;//41
double record[STATE_NUM][TABLE_NUM * QUERY_NUM];		//[query][table][state], query from 0, state from 0, table from 1
int mask[STATE_NUM][TABLE_NUM * QUERY_NUM];
double weight[TABLE_NUM * QUERY_NUM];*/
#define TABLE_NUM 8//8
#define QUERY_NUM 14//14
#define STATE_NUM 72//41
//-----------------------------------
void list_filename(char **fn_list, int *fn_cnt)
{
	DIR *dp;
	struct dirent *ep;

	dp = opendir ("./");
	if (dp != NULL)
	{
		while (ep = readdir (dp))
		{
			//puts (ep->d_name);
			if (strstr(ep->d_name, ".tsv") != NULL)
			{
				fn_list[*fn_cnt] = (char *)malloc(sizeof(char) * 256);
				strcpy(fn_list[*fn_cnt], ep->d_name);
				++(*fn_cnt);
			}
		}
		(void) closedir (dp);
	}
	else
		perror ("Couldn't open the directory");

	return;
}
//-----------------------------------
void recursive_output_tree_to_json(int nelement, int root, FILE *fp, char **fn_list, int **cluster_rec)
{
	if (root >= 0 && root < nelement)
	{
		printf("{\n");
		printf("\"name\": \"%s\"\n", fn_list[root]);
		printf("}\n");
		
		return;
	}
	else
	{
		printf("{\n");
		printf("\"name\": \"%s\",\n", "tmp");
		printf("\"children\": [\n");
		recursive_output_tree_to_json(nelement, cluster_rec[-root][0], fp, fn_list, cluster_rec);
		printf(",\n");
		recursive_output_tree_to_json(nelement, cluster_rec[-root][1], fp, fn_list, cluster_rec);
		printf("]\n");
		printf("}\n");
		
		return;
	}
}
//-----------------------------------
int main()
{
	int i, j, k, l;
	char **fn_list = (char **)malloc(sizeof(char *) * 100);
	int fn_cnt = 0;
	//const int TABLE_NUM = 8;//8
	//const int QUERY_NUM = 14;//14
	//const int STATE_NUM = 53;//41
	double **record = (double **)malloc(STATE_NUM * sizeof(double *));
	for (i = 0; i < STATE_NUM; ++i)
		record[i] = (double *)malloc(TABLE_NUM * QUERY_NUM * sizeof(double));		//[query][table][state], query from 0, state from 0, table from 1
	int **mask = (int **)malloc(STATE_NUM * sizeof(int *));
	for (i = 0; i < STATE_NUM; ++i)
		mask[i] = (int *)malloc(TABLE_NUM * QUERY_NUM * sizeof(int));
	double *weight = (double *)malloc(TABLE_NUM * QUERY_NUM * sizeof(double));

	FILE *fp;
	int tmpi, tmpj, tmp_step;
	char *tmps = (char *)malloc(sizeof(char) * 20);
	
	
	list_filename(fn_list, &fn_cnt);
	
	
	
	for (i = 1; i < STATE_NUM; ++i)
	{
		for (j = 0; j < QUERY_NUM * TABLE_NUM; ++j)
		{
			record[i][j] = 0;
			mask[i][j] = 1;
			weight[j] = 1;
		}
	}
	
	
	//---------for-debug-begin----------
	//strcpy(fn_list[0], "idx_none.tsv");
	//fn_cnt = 1;
	//---------for-debug-end------------
	
	for (i = 0; i < fn_cnt; ++i)
	{
		fp = fopen(fn_list[i], "r");
		if (fp == NULL)
		{
			printf("open file error: %s\n", fn_list[i]);
			return 0;
		}
		
		fscanf(fp, "%s	%s	%s\n", tmps, tmps, tmps);
		for (j = 1; j <= TABLE_NUM; ++j)
		{
			for (k = 0; k < QUERY_NUM; ++k)
			{
				fscanf(fp, "%d	%d	%d\n", &tmpi, &tmpj, &tmp_step);
				record[i][(j-1)*QUERY_NUM+k] = tmp_step;
			}
			fscanf(fp, "%d	%d	%d\n", &tmpi, &tmpj, &tmp_step); //to skip the row_summary cells
		}
		fclose(fp);
	}
	
	int **cluster_rec = (int **)malloc(STATE_NUM * sizeof(int *));
	for (i = 0; i < STATE_NUM; ++i)
		cluster_rec[i] = (int *)malloc(TABLE_NUM * QUERY_NUM * sizeof(int));
	Node *res_tree = treecluster_rec(STATE_NUM, TABLE_NUM * QUERY_NUM, record, mask, weight, 0, 'e', 'a', NULL, cluster_rec);
	
	FILE *fpout = fopen("cluster.json", "w+");
	recursive_output_tree_to_json(STATE_NUM, -(STATE_NUM - 1), fp, fn_list, cluster_rec);
	
	//printf("done");
}	
	
	
	
	
	
	
	
