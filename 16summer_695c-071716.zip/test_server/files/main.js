console.log("Before making the request");

d3.json("/test_json/blabla\"", function(error, json) {
    if (error) {
        console.error(error);
    } else {
        console.log("Success!");
        console.log(json);
    }
});

console.log("After making the request");
