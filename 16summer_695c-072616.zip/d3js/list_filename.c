//http://linux.die.net/man/3/readdir

#include <stdio.h>
#include <sys/types.h>
#include <dirent.h>
#include <stdlib.h>
#include <string.h>
//-----------------------------------
char **fn_list = (char **)malloc(sizeof(char *) * 100);
int fn_cnt = 0;
const int TABLE_NUM = 8;
const int QUERY_NUM = 14;
//-----------------------------------
void list_filename()
{
	DIR *dp;
	struct dirent *ep;

	dp = opendir ("./");
	if (dp != NULL)
	{
		while (ep = readdir (dp))
		{
			//puts (ep->d_name);
			if (strstr(ep->d_name, ".tsv") != NULL)
			{
				fn_list[fn_cnt] = (char *)malloc(sizeof(char) * 256);
				strcpy(fn_list[fn_cnt], ep->d_name);
				++fn_cnt;
			}
		}
		(void) closedir (dp);
	}
	else
		perror ("Couldn't open the directory");

	return;
}
//----------------------------------
int main()
{
	FILE *fp;
	int record[500][20];
	int tmpi, tmpj, tmp_step;
	char *tmps = (char *)malloc(sizeof(char) * 20);
	
	
	list_filename();
	
	int i, j, k;
	for (i = 1; i <= TABLE_NUM; ++i)
	{
		for (j = 0; j < QUERY_NUM; ++j)
		{
			record[j][i] = 0;
		}
	}
	
	for (k = 0; k < fn_cnt; ++k)
	{
		fp = fopen(fn_list[k], "r");
		if (fp == NULL)
		{
			printf("open file error\n");
			return 0;
		}
		
		fscanf(fp, "%s	%s	%s\n", tmps, tmps, tmps);
		for (i = 1; i <= TABLE_NUM; ++i)
		{
			for (j = 0; j < QUERY_NUM; ++j)
			{
				fscanf(fp, "%d	%d	%d\n", &tmpi, &tmpj, &tmp_step);
				record[j][i] += tmp_step;
				if (i == 7 && j == 8)
					printf("%s: %d\n", fn_list[k], tmp_step);
			}
		}
		fclose(fp);
	}
	
	FILE *fp_out = fopen("idx_avg.tsv", "w+");
	if (fp_out == NULL)
	{
		printf("open output file error\n");
		return 0;
	}
	
	fprintf(fp_out, "table	query	scanstep\n");
	for (i = 1; i <= TABLE_NUM; ++i)
	{
		for (j = 0; j < QUERY_NUM; ++j)
		{
			fprintf(fp_out, "%d	%d	%d\n", i, j, record[j][i] / fn_cnt);
		}
	}
	
	fclose(fp_out);
	return 0;
}




